=== Zodkoo Shortcode ===

Contributors: widget,visual composer addon shortcode,custom post type
== Description ==

You are bored to see the custom post type,widget and visual composer addon.
== Installation ==


This is pretty simple. Follow the step below. Install through wordpress.org

1. Visit 'Plugins > Add New'
2. Search for 'appestia_shortcode'
3. Activate appestia_shortcodefrom your Plugins page. (You will be greeted with a Welcome page.)

Manual install:

1. Upload `zodkoo-shortcode.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place `<?php do_action('plugin_name_hook'); ?>` in your templates


== Frequently Asked Questions ==

= Can I use my existing WordPress theme? =


Yes, you can.


= Will this work on WordPress multisite? =


Yes, it will.

== Screenshots ==

1. Front end

 of the Plugin.
2. Shortcode.
3. Full option part one.
4. Full option part two
== Changelog ==


= 1.0 =

* Initial Release.