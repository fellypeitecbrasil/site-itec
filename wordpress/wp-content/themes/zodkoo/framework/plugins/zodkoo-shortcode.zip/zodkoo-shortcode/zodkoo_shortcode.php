<?php
/*
Plugin Name: Zodkoo Shortcode
Plugin URI: http://www.zodkoo.com/
Description: A plugin to create custom post type,widget, shortcode...
Version: 1.0
Author: Zodkoo
Author URI: http://www.zodkoo.com/
License: GPL
*/
	include dirname(__FILE__) . '/visual_composer_addons/vc_element.php';
    include dirname(__FILE__) . '/visual_composer_addons/vc_shortcode.php';
    include dirname(__FILE__) . '/metabox/zodkoo-page-title-metabox.php';
    return true;
